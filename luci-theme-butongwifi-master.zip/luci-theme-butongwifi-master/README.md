# luci-theme-butongwifi
openwrt luci主题，具有PC和手机自适应的特性，界面简洁大方，响应快。个人感觉比市面上90%的openwrt主题都要好用。
本人从[不同生活共享WiFi](http://butong.me "不同生活共享WiFi")的固件提取出来，分享给大家。无偿随意使用。
要是好用的话，请多分享给其他有需要的人吧。欢迎大家一起完善。

> * git clone到openwrt的源码目录，如openwrt-src/package/mypackage/luci-theme-butongwifi
> * make menuconfig，进入luci->themes，选择luci-theme-butongwifi，保存退出，make V=99编译。

## 界面预览：
![login](https://github.com/aboutboy/luci-theme-butongwifi/blob/master/preview/login.png?raw=true)
![index](https://github.com/aboutboy/luci-theme-butongwifi/blob/master/preview/index.png?raw=true)
![menu](https://github.com/aboutboy/luci-theme-butongwifi/blob/master/preview/menu.png?raw=true)
![login_mobile](https://github.com/aboutboy/luci-theme-butongwifi/blob/master/preview/login_mobile.png?raw=true)
![index_mobile](https://github.com/aboutboy/luci-theme-butongwifi/blob/master/preview/index_mobile.png?raw=true)
![menu_mobile](https://github.com/aboutboy/luci-theme-butongwifi/blob/master/preview/menu_mobile.png?raw=true)
![menu2_mobile](https://github.com/aboutboy/luci-theme-butongwifi/blob/master/preview/menu2_mobile.png?raw=true)
